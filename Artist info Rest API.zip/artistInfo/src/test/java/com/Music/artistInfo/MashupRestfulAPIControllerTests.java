package com.Music.artistInfo;

import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import com.Music.artistInfo.controller.MashupRestfulAPIController;
import com.Music.artistInfo.model.AlbumsData;
import com.Music.artistInfo.model.AllInfo;
import com.Music.artistInfo.service.RestfulServices;
import org.springframework.http.MediaType;

@RunWith(SpringRunner.class)
@WebMvcTest(value = MashupRestfulAPIController.class, secure = false)
public class MashupRestfulAPIControllerTests {

	private MockMvc mockMvc;

	@MockBean
	private RestTemplate restTemplate;

	@MockBean
	private RestfulServices restfulServicesMock;

	@Autowired
	private WebApplicationContext webApplicationContext;

	@Before
	public void setUp() {
		Mockito.reset(restfulServicesMock);
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	AllInfo mockAllInfo = new AllInfo("5b11f4ce-a62d-471e-81fc-a69a8278c7da", "Band information",
			new AlbumsData[] { new AlbumsData("123456", "album name",
					"http://coverartarchive.org/release/726ca690-fe70-4d3f-86b5-f8347f1a1af0/1289818412.jpg") });
	String mbid = "5b11f4ce-a62d-471e-81fc-a69a8278c7da";

	@Test
	public void MbidFoundReturnOkStatus() throws Exception {
		when(restfulServicesMock.getAllInfo(mbid)).thenReturn(mockAllInfo);
		mockMvc.perform(get("/api/{id}", mbid))
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.mbid", is("5b11f4ce-a62d-471e-81fc-a69a8278c7da")))
				.andExpect(jsonPath("$.description", is("Band information")));

		verify(restfulServicesMock, times(1)).getAllInfo(mbid);
		verifyNoMoreInteractions(restfulServicesMock);
	}

	@Test
	public void MbidNotFoundReturnInternalServerErrorStatus() throws Exception {
		when(restfulServicesMock.getAllInfo(mbid)).thenThrow(new JSONException(""));

		mockMvc.perform(get("/api/{id}", mbid))
			.andExpect(status().isInternalServerError());

		verify(restfulServicesMock, times(1)).getAllInfo(mbid);
		verifyNoMoreInteractions(restfulServicesMock);
	}

}
