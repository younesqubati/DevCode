package com.Music.artistInfo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AlbumsData {
	private String id ;
	private String title;
	private String image;
	
	public AlbumsData() {};
	
	public AlbumsData(String id, String title,String image) {
		this.id = id;
		this.title = title;
		this.image=image;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
	

//	@Override
//	public String toString() {
//		return "Quote{" + "mbid='" + data + '\'' + ", value=" + title + '}';
//	}
}
