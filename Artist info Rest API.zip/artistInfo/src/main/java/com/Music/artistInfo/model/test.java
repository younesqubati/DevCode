package com.Music.artistInfo.model;

import org.springframework.stereotype.Component;

@Component
public class test {
	String a;
	boolean b;
	public String getA() {
		return a;
	}
	
	public void setA(String a) {
		this.a = a;
	}
	
	public boolean isB() {
		return b;
	}
	public void setB(boolean b) {
		this.b = b;
	}
	public test(String a,boolean b) {
		this.a = a;
		this.b = b;
	}
	public test() {
	}

}
