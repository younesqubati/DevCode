package com.Music.artistInfo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AllInfo {
	private String mbid;
	private String description;
	private AlbumsData[] albums;
	
	public AllInfo() {}

	public AllInfo(String mbid, String description, AlbumsData[] albums) {
		this.mbid = mbid;
		this.description = description;
		this.albums = albums;
	}

	public String getMbid() {
		return mbid;
	}

	public void setMbid(String mbid) {
		this.mbid = mbid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public AlbumsData[] getAlbums() {
		return albums;
	}

	public void setAlbums(AlbumsData[] albums) {
		this.albums = albums;
	}

}
