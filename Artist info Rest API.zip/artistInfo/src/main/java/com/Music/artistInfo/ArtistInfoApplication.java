package com.Music.artistInfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.Music.artistInfo.service.RestfulServices;

@SpringBootApplication
public class ArtistInfoApplication {
	public static void main(String args[]) {
		SpringApplication.run(ArtistInfoApplication.class);
	}
	
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
	
	@Bean
	public RestfulServices restfulServices() {
		return new RestfulServices();
	}

}