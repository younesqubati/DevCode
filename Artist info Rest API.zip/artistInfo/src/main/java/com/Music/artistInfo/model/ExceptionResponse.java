package com.Music.artistInfo.model;

import org.springframework.stereotype.Component;

@Component
public class ExceptionResponse {
	private int code;
	private String ErrorMessage;
	
	public void setCode(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public String getErrorMessage() {
		return ErrorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		ErrorMessage = errorMessage;
	}


}
