package com.Music.artistInfo.service;

import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.Music.artistInfo.model.AlbumsData;
import com.Music.artistInfo.model.AllInfo;

public class RestfulServices {
	
	@Autowired
	RestTemplate restTemplate;

	public AllInfo getAllInfo(String mbid) throws JSONException {
		String url = "http://musicbrainz.org/ws/2/artist/"+mbid+"?&fmt=json&inc=url-rels+release-groups";
		JSONObject obj;
		String description = null;
		String image;
		String title;
		String albumId;
		AlbumsData[] albums = null;
		String jsonData = restTemplate.getForObject(url, String.class);
		obj = new JSONObject(jsonData);
		mbid = obj.getString("id");
		description = fetchDescriptionFromRESTfulAPI(fetchWikipediaDataFromRESTfulAPI(obj));
		JSONArray releaseGroupsArray = obj.getJSONArray("release-groups");
		albums = new AlbumsData[releaseGroupsArray.length()];
		for (int i = 0; i < releaseGroupsArray.length(); i++) {
			JSONObject relation = releaseGroupsArray.getJSONObject(i);
			title = relation.getString("title");
			albumId = relation.getString("id");
			image = fetchImageFromRESTfulAPI(albumId);
			albums[i] = new AlbumsData(albumId, title, image);
		}
		return new AllInfo(mbid, description, albums);
	}
	
	@SuppressWarnings("finally")
	public String fetchImageFromRESTfulAPI(String id) {
		String url = "http://coverartarchive.org/release-group/" + id;
		JSONObject obj;
		String image = null;
		String jsonData;
		try {
			jsonData = restTemplate.getForObject(url, String.class);
			obj = new JSONObject(jsonData);
			JSONArray imagesArray = obj.getJSONArray("images");
			JSONObject imageObject = imagesArray.getJSONObject(0);
			image = imageObject.getString("image");
		} catch (JSONException e) {
			System.out.println("Error with fetchImageFromRESTfulAPI");
		}
		finally {
			if(image!=null) {
				return image;
			}
			return image="No image found";
		}
		
	}
	
	@SuppressWarnings("finally")
	public String fetchWikipediaDataFromRESTfulAPI(JSONObject obj) {
		String wikipediaName = null;
		JSONArray relationArray;
		String wikipediaData;
		try {
			relationArray = obj.getJSONArray("relations");
			for (int i = 0; i < relationArray.length(); i++) {
				JSONObject relationObject = relationArray.getJSONObject(i);
				wikipediaData = relationObject.getJSONObject("url").getString("resource");
				if (wikipediaData.toLowerCase().contains("wikipedia")) {
					String[] a = wikipediaData.split("/");
					wikipediaName = a[a.length - 1];
				}
			}
		} catch (JSONException e) {
			System.out.println("Error with fetchWikipediaDataFromRESTfulAPI");
		}
		finally {
			if(wikipediaName!=null) {
				return wikipediaName;
			}
			return wikipediaName="No wikipedia data found";
		}
	}
	
	@SuppressWarnings("finally")
	public String fetchDescriptionFromRESTfulAPI(String wikipediaName) {
		String url = "https://en.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=true&redirects=true&titles="
				+ wikipediaName;
		JSONObject obj;
		String description = null;
		String jsonData;
		try {
			jsonData = restTemplate.getForObject(url, String.class);
			obj = new JSONObject(jsonData);
			JSONObject pagesArray = obj.getJSONObject("query").getJSONObject("pages");
			Iterator<?> keys = pagesArray.keys();
			String key = (String) keys.next();
			description = pagesArray.getJSONObject(key).getString("extract");
		} catch (JSONException e) {
			System.out.println("Error with fetchDescriptionFromRESTfulAPI");
		}
		finally {
			if(description!=null) {
				return description;
			}
			return description="No description found";
		}
	}
	
}
