package com.Music.artistInfo.controller;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Music.artistInfo.model.AllInfo;
import com.Music.artistInfo.service.RestfulServices;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping(path="/api/")
@Api(value="ArtistControllerAPI", produces = MediaType.APPLICATION_JSON_VALUE)
public class MashupRestfulAPIController {
	
	@Autowired
	private RestfulServices restfulServices;

	
	@RequestMapping(path="{mbid}" , method=RequestMethod.GET)
	@ApiOperation("Get artist information with specific MBID (MusicBrainz Identifier)")
	@ApiResponses(value= {@ApiResponse(code=200,message="OK",response=AllInfo.class)})
	public AllInfo getAllInfoMashup(@PathVariable(name="mbid") String mbid) throws JSONException {
		return restfulServices.getAllInfo(mbid);
	}


	

	

	

}
